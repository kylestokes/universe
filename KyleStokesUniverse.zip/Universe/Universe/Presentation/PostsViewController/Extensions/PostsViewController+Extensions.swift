//
//  PostsViewController+Extensions.swift
//  Universe
//
//  Created by Kyle Stokes on 6/1/22.
//

import Foundation
import UIKit

// MARK: - UITableViewDataSource

extension PostsViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let posts = posts else { return 0 }
        return posts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as? PostsTableViewCell else {
            return UITableViewCell()
        }
        let post = posts?[indexPath.row]
        cell.configureWith(title: post?.title, subtitle: post?.body)
        
        return cell
    }
}

// MARK: - UITableViewDelegate

extension PostsViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let detailViewController = DetailViewController(post: posts?[indexPath.row])
        navigationController?.pushViewController(detailViewController, animated: true)
    }
}
