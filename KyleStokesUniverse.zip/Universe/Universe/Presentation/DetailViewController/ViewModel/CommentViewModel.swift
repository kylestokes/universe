//
//  CommentViewModel.swift
//  Universe
//
//  Created by Kyle Stokes on 6/1/22.
//

import Foundation

struct CommentViewModel {
    var commentRepo: CommentRepo?
    
    init(commentRepo: CommentRepo = CommentRepoImpl()) {
        self.commentRepo = commentRepo
    }
    
    func getComments(for postId: Int) async throws -> [Comment]? {
        return try await commentRepo?.getComments(for: postId)
    }
}
