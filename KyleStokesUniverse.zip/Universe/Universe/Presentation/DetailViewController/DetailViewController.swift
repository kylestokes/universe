//
//  DetailViewController.swift
//  Universe
//
//  Created by Kyle Stokes on 6/1/22.
//

import Foundation
import UIKit

class DetailViewController: UIViewController {
    let commentTableView = UITableView()
    let commentViewModel = CommentViewModel()
    var post: Post?
    var comments: [Comment]? {
        didSet {
            commentTableView.reloadData()
        }
    }
    
    deinit {
        removeDelegates()
    }
    
    init(post: Post?) {
        super.init(nibName: nil, bundle: nil)
        self.post = post
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupDelegates()
        setupUI()
        setupTableView()
        getAllComments()
    }
    
    private func setupDelegates() {
        setTableViewDelegate(to: self)
    }
    
    private func removeDelegates() {
        setTableViewDelegate(to: nil)
    }
    
    private func setupUI() {
        typealias constants = PresentationConstants
        guard let post = post else { return }
        title = "\(constants.post) \(post.id)"
        view.backgroundColor = .white
    }
    
    private func setTableViewDelegate(to controller: UIViewController?) {
        commentTableView.delegate = controller as? UITableViewDelegate
        commentTableView.dataSource = controller as? UITableViewDataSource
    }
    
    private func setupTableView() {
        commentTableView.allowsSelection = false
        commentTableView.register(
            DetailTableViewCell.self,
            forCellReuseIdentifier: Identifiers.detailCell
        )
        commentTableView.register(
            CommentTableViewCell.self,
            forCellReuseIdentifier: Identifiers.commentCell
        )
        
        view.addSubview(commentTableView)
        let safeArea = view.layoutMarginsGuide
        commentTableView.translatesAutoresizingMaskIntoConstraints = false
        commentTableView.topAnchor.constraint(equalTo: safeArea.topAnchor).isActive = true
        commentTableView.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        commentTableView.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor).isActive = true
        commentTableView.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
    }
    
    private func getAllComments() {
        Task {
            await getComments()
        }
    }
    
    private func getComments() async {
        do {
            guard let post = post else { return }
            comments = try await commentViewModel.getComments(for: post.id)
        } catch {
            /// Send metrics/alert user instead of crashing
            fatalError("Unable to get comments.")
        }
    }
}
