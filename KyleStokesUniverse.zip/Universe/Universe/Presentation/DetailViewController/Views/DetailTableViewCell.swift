//
//  DetailTableViewCell.swift
//  Universe
//
//  Created by Kyle Stokes on 6/2/22.
//

import Foundation
import UIKit

protocol DetailTableViewCellDelegate {
    func didTap(cell: DetailTableViewCell)
}

class DetailTableViewCell: UITableViewCell {
    static let height: CGFloat = 200
    
    var delegate: DetailTableViewCellDelegate?
    
    deinit {
        delegate = nil
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .subtitle, reuseIdentifier: reuseIdentifier)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        let padding = UIEdgeInsets(top: -52, left: 0, bottom: 0, right: 0)
        contentView.frame = contentView.frame.inset(by: padding)
    }
    
    private func setupButton() {
        let button = UIButton()
        button.backgroundColor = .black
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 14)
        button.layer.cornerRadius = 14
        button.setTitle(PresentationConstants.seeMore, for: .normal)
        contentView.addSubview(button)
        button.addTarget(
            self,
            action: #selector(didTapSeeMore),
            for: .touchUpInside
        )
        
        button.translatesAutoresizingMaskIntoConstraints = false
        button.leadingAnchor.constraint(
            equalTo: contentView.leadingAnchor,
            constant: 18
        )
        .isActive = true
        button.widthAnchor.constraint(
            equalToConstant: 165
        )
        .isActive = true
        button.bottomAnchor.constraint(
            equalTo: contentView.bottomAnchor,
            constant: -24
        )
        .isActive = true
    }
    
    func configureWith(title: String?, subtitle: String?) {
        var content = UIListContentConfiguration.subtitleCell()
        content.text = title?.localizedCapitalized
        content.textProperties.font = UIFont.boldSystemFont(ofSize: 16)
        content.textProperties.color = .darkText
        content.secondaryTextProperties.color = .black
        content.secondaryText = subtitle?.localizedCapitalized
        content.textToSecondaryTextVerticalPadding = 4
        self.contentConfiguration = content
        setupButton()
    }
    
    @objc
    private func didTapSeeMore() {
        delegate?.didTap(cell: self)
    }
}
