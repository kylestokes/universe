//
//  Comment.swift
//  Universe
//
//  Created by Kyle Stokes on 6/1/22.
//

import Foundation

/**
 {
    "postId": 1,
    "id": 1,
    "name": "id labore ex et quam laborum",
    "email": "Eliseo@gardner.biz",
    "body": "laudantium enim quasi est quidem..."
  }
 */

struct Comment: Decodable {
    var id: Int
    var postId: Int
    var name: String
    var email: String
    var body: String
}
