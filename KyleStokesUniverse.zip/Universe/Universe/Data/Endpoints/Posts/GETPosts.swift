//
//  GETPosts.swift
//  Universe
//
//  Created by Kyle Stokes on 6/1/22.
//

import Foundation

class GETPosts {
    var userId: Int?
    var endpoint: URL? {
        if let userId = userId {
            let userPosts = URLConstants.userPosts.rawValue
            return URL(
                string: userPosts.replacingOccurrences(
                    of: URLConstants.paramIdentifier.rawValue,
                    with: "\(userId)"
                )
            )
        } else {
            return URL(string: URLConstants.posts.rawValue)
        }
    }
    
    init(userId: Int?) {
        self.userId = userId
    }
}
