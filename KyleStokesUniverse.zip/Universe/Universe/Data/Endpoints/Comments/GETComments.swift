//
//  GETComments.swift
//  Universe
//
//  Created by Kyle Stokes on 6/1/22.
//

import Foundation

class GETComments {
    var postId: Int
    var endpoint: URL? {
        let comments = URLConstants.comments.rawValue
        return URL(
            string: comments.replacingOccurrences(
                of: URLConstants.paramIdentifier.rawValue,
                with: "\(postId)"
            )
        )
    }
    
    init(postId: Int) {
        self.postId = postId
    }
}
