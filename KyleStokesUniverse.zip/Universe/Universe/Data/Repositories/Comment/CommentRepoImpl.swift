//
//  CommentRepoImpl.swift
//  Universe
//
//  Created by Kyle Stokes on 6/1/22.
//

import Foundation

class CommentRepoImpl: CommentRepo {
    let session = URLSession.shared
    
    func getComments(for postId: Int) async throws -> [Comment] {
        guard let getCommentsEndpoint = GETComments(postId: postId).endpoint else {
             fatalError("Unable to get GETComments endpoint.")
        }
        let (data, response) = try await session.data(from: getCommentsEndpoint)
        guard (response as? HTTPURLResponse)?.statusCode == 200 else {
            fatalError("Unable to get comments from: \(getCommentsEndpoint.absoluteString)")
        }
        let decoder = JSONDecoder()
        return try decoder.decode([Comment].self, from: data)
    }
}
