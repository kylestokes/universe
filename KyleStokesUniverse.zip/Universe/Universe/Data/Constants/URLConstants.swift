//
//  URLConstants.swift
//  Universe
//
//  Created by Kyle Stokes on 6/1/22.
//

import Foundation

enum URLConstants: String {
    case paramIdentifier = "$"
    case posts = "https://jsonplaceholder.typicode.com/posts"
    case userPosts = "https://jsonplaceholder.typicode.com/users/$/posts"
    case comments = "https://jsonplaceholder.typicode.com/posts/$/comments"
}
