//
//  CommentRepo.swift
//  Universe
//
//  Created by Kyle Stokes on 6/1/22.
//

import Foundation

protocol CommentRepo {
    func getComments(for postId: Int) async throws -> [Comment]
}
