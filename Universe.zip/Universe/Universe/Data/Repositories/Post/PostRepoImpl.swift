//
//  PostRepoImpl.swift
//  Universe
//
//  Created by Kyle Stokes on 6/1/22.
//

import Foundation

class PostRepoImpl: PostsRepo {
    let session = URLSession.shared
    
    /// Could consider having custom network layer that generalizes thte validation and decoding
    func getPosts(for userId: Int?) async throws -> [Post] {
        guard let getPostsEndpoint = GETPosts(userId: userId).endpoint else {
             fatalError("Unable to get GETPosts endpoint.")
        }
        let (data, response) = try await session.data(from: getPostsEndpoint)
        guard (response as? HTTPURLResponse)?.statusCode == 200 else {
            fatalError("Unable to get posts from: \(getPostsEndpoint.absoluteString)")
        }
        let decoder = JSONDecoder()
        return try decoder.decode([Post].self, from: data)
    }
}
