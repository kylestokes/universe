//
//  PostsRepo.swift
//  Universe
//
//  Created by Kyle Stokes on 6/1/22.
//

import Foundation

protocol PostsRepo {
    func getPosts(for userId: Int?) async throws -> [Post]
}
