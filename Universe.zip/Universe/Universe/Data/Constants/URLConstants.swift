//
//  URLConstants.swift
//  Universe
//
//  Created by Kyle Stokes on 6/1/22.
//

import Foundation

enum URLConstants: String {
    case host = "jsonplaceholder.typicode.com"
    case posts = "/posts"
    
    enum Schemes: String {
        case http = "http"
        case https = "https"
    }
}
