//
//  Identifiers.swift
//  Universe
//
//  Created by Kyle Stokes on 6/1/22.
//

import Foundation

struct Identifiers {
    static let postsCell = "PostsTableViewCell"
    static let detailCell = "DetailTableViewCell"
    static let commentCell = "CommentTableViewCell"
}
