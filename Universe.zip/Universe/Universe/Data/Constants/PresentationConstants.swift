//
//  PresentationConstants.swift
//  Universe
//
//  Created by Kyle Stokes on 6/1/22.
//

import Foundation

struct PresentationConstants {
    static let user = "User"
    static let post = "Post"
    static let posts = "Posts"
    static let comments = "Comments"
    static let seeMore = "See More by Author"
}
