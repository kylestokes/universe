//
//  Post.swift
//  Universe
//
//  Created by Kyle Stokes on 6/1/22.
//

import Foundation

/**
 {
    "userId": 1,
    "id": 1,
    "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
    "body": "quia et suscipit\nsuscipit recusandae con..."
  }
 */

struct Post: Decodable {
    var id: Int
    var userId: Int
    var title: String
    var body: String
}
