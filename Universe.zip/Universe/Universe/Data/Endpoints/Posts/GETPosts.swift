//
//  GETPosts.swift
//  Universe
//
//  Created by Kyle Stokes on 6/1/22.
//

import Foundation

class GETPosts {
    var userId: Int?
    var endpoint: URL? {
        var components = URLComponents()
        components.scheme = URLConstants.Schemes.https.rawValue
        components.host = URLConstants.host.rawValue
        if let userId = userId {
            components.path = "/users/\(userId)/posts"
        } else {
            components.path = URLConstants.posts.rawValue
        }
        return components.url
    }
    
    init(userId: Int?) {
        self.userId = userId
    }
}
