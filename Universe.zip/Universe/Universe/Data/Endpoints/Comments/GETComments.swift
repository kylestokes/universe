//
//  GETComments.swift
//  Universe
//
//  Created by Kyle Stokes on 6/1/22.
//

import Foundation

class GETComments {
    var postId: Int
    var endpoint: URL? {
        var components = URLComponents()
        components.scheme = URLConstants.Schemes.https.rawValue
        components.host = URLConstants.host.rawValue
        components.path = "/posts/\(postId)/comments"
        return components.url
    }
    
    init(postId: Int) {
        self.postId = postId
    }
}
