//
//  CommentTableViewCell.swift
//  Universe
//
//  Created by Kyle Stokes on 6/1/22.
//

import Foundation
import UIKit

class CommentTableViewCell: UITableViewCell {
    static let height: CGFloat = 175
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .subtitle, reuseIdentifier: reuseIdentifier)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()

        let padding = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 16)
        contentView.frame = contentView.frame.inset(by: padding)
    }
    
    func configureWith(name: String?, email: String?, body: String?) {
        var content = UIListContentConfiguration.subtitleCell()
        
        if let name = name, let email = email {
            let titleAttributes = [
                NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 16),
                NSAttributedString.Key.foregroundColor : UIColor.black
            ]
            let emailAttributes = [
                NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 11),
                NSAttributedString.Key.foregroundColor : UIColor.systemBlue
            ]
            let title = NSMutableAttributedString(
                string: name,
                attributes: titleAttributes
            )
            let email = NSMutableAttributedString(
                string: "\(email)\n",
                attributes: emailAttributes
            )
            email.append(title)
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.lineSpacing = 4
            email.addAttribute(
                NSAttributedString.Key.paragraphStyle,
                value: paragraphStyle,
                range: NSMakeRange(0, email.length)
            )
            content.attributedText = email
        } else {
            content.text = name
            content.textProperties.font = UIFont.boldSystemFont(ofSize: 14)
        }
        content.textProperties.numberOfLines = .zero
        content.secondaryTextProperties.color = .gray
        content.secondaryTextProperties.numberOfLines = .zero
        content.textToSecondaryTextVerticalPadding = 12
        content.secondaryText = body?.localizedCapitalized
        self.contentConfiguration = content
    }
}
