//
//  DetailViewController+Extensions.swift
//  Universe
//
//  Created by Kyle Stokes on 6/1/22.
//

import Foundation
import UIKit

// MARK: - UITableViewDataSource

extension DetailViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let comments = comments else { return 0 }
        switch section {
        case 0:
            return 1
        default:
            return comments.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.section {
        case 0:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: Identifiers.detailCell, for: indexPath) as? DetailTableViewCell else {
                return UITableViewCell()
            }
            cell.delegate = self
            cell.configureWith(
                title: post?.title,
                subtitle: post?.body
            )
            
            return cell
        default:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: Identifiers.commentCell, for: indexPath) as? CommentTableViewCell else {
                return UITableViewCell()
            }
            let comment = comments?[indexPath.row]
            cell.configureWith(
                name: comment?.name,
                email: comment?.email,
                body: comment?.body
            )
            
            return cell
        }
    }
}

// MARK: - UITableViewDelegate

extension DetailViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.section {
        case 0:
            return DetailTableViewCell.height
        default:
            return CommentTableViewCell.height
        }
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0:
            return nil
        default:
            return PresentationConstants.comments
        }
    }
}

// MARK: - DetailTableViewCellDelegate

extension DetailViewController: DetailTableViewCellDelegate {
    func didTap(cell: DetailTableViewCell) {
        let postViewController = PostsViewController(userId: post?.userId)
        navigationController?.pushViewController(postViewController, animated: true)
    }
}
