//
//  PostsViewModel.swift
//  Universe
//
//  Created by Kyle Stokes on 6/1/22.
//

import Foundation

struct PostsViewModel {
    var postsRepo: PostsRepo?
    
    init(postsRepo: PostsRepo = PostRepoImpl()) {
        self.postsRepo = postsRepo
    }
    
    func getPosts(for userId: Int? = nil) async throws -> [Post]? {
        return try await postsRepo?.getPosts(for: userId)
    }
}
