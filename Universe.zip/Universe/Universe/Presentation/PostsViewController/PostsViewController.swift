//
//  PostsViewController.swift
//  Universe
//
//  Created by Kyle Stokes on 6/1/22.
//

import UIKit

class PostsViewController: UIViewController {
    let postsTableView = UITableView()
    let postsViewModel = PostsViewModel()
    let reuseIdentifier = Identifiers.postsCell
    var userId: Int?
    var posts: [Post]? {
        didSet {
            postsTableView.reloadData()
        }
    }
    
    deinit {
        removeDelegates()
    }
    
    init(userId: Int? = nil) {
        super.init(nibName: nil, bundle: nil)
        self.userId = userId
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupDelegates()
        setupUI()
        setupTableView()
        getAllPosts()
    }
    
    private func setupDelegates() {
        setTableViewDelegate(to: self)
    }
    
    private func removeDelegates() {
        setTableViewDelegate(to: nil)
    }
    
    private func setupUI() {
        typealias constants = PresentationConstants
        if let userId = userId {
            title = "\(constants.user) \(userId) \(constants.posts)".localizedCapitalized
        } else {
            title = constants.posts.localizedCapitalized
        }
        navigationController?.navigationBar.prefersLargeTitles = true
        view.backgroundColor = .white
    }
    
    private func setTableViewDelegate(to controller: UIViewController?) {
        postsTableView.delegate = controller as? UITableViewDelegate
        postsTableView.dataSource = controller as? UITableViewDataSource
    }
    
    private func setupTableView() {
        postsTableView.register(
            PostsTableViewCell.self,
            forCellReuseIdentifier: reuseIdentifier
        )
        
        view.addSubview(postsTableView)
        let safeArea = view.layoutMarginsGuide
        postsTableView.translatesAutoresizingMaskIntoConstraints = false
        postsTableView.topAnchor.constraint(equalTo: safeArea.topAnchor).isActive = true
        postsTableView.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        postsTableView.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor).isActive = true
        postsTableView.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
    }
    
    private func getAllPosts() {
        Task {
            await getPosts()
        }
    }
    
    private func getPosts() async {
        do {
            posts = try await postsViewModel.getPosts(for: userId)
        } catch {
            /// Send metrics/alert user instead of crashing
            fatalError("Unable to get posts.")
        }
    }
}
