//
//  PostsTableViewCell.swift
//  Universe
//
//  Created by Kyle Stokes on 6/1/22.
//

import Foundation
import UIKit

class PostsTableViewCell: UITableViewCell {
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .subtitle, reuseIdentifier: reuseIdentifier)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()

        let padding = UIEdgeInsets(top: 10, left: 8, bottom: 10, right: 8)
        contentView.frame = contentView.frame.inset(by: padding)
    }
    
    func configureWith(title: String?, subtitle: String?) {
        var content = UIListContentConfiguration.subtitleCell()
        content.text = title?.localizedCapitalized
        content.textProperties.font = UIFont.boldSystemFont(ofSize: 16)
        content.secondaryTextProperties.color = .gray
        content.secondaryText = subtitle?.localizedCapitalized
        self.contentConfiguration = content
        self.accessoryType = .disclosureIndicator
    }
}
